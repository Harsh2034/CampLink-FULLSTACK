import React, { useContext } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link, NavLink, useNavigate } from 'react-router-dom';
import { AuthProvider, AuthContext } from './context/AuthContext';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Marketplace from './pages/Marketplace';
import Profile from './pages/Profile';
import Activity from './pages/Activity';
import AdminDashboard from './pages/AdminDashboard';
import ProjectDetail from './pages/ProjectDetail';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import { Moon, Sun } from 'lucide-react';
import './index.css';

const Navbar = () => {
    const { currentUser, logout, theme, toggleTheme } = useContext(AuthContext);
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    return (
        <header className="navbar">
            <nav className="container nav-content">
                <Link to="/" className="logo">
                    <div className="logo-icon"></div>
                    <span id="name">Camp-Link</span>
                </Link>
                <div className="nav-buttons">
                    <button id="theme-toggle-btn" className="btn btn-outline" style={{ padding: '0.5rem' }} onClick={toggleTheme}>
                        {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
                    </button>
                    
                    {!currentUser ? (
                        <div id="auth-nav-buttons" className="nav-buttons">
                            <Link to="/admin-login" className="btn btn-ghost">Admin Login</Link>
                            <Link to="/login" className="btn btn-outline">Login</Link>
                            <Link to="/signup" className="btn btn-solid">Get Started</Link>
                        </div>
                    ) : (
                        <div id="app-nav-buttons" className="nav-buttons">
                            {currentUser.isAdmin ? (
                                <NavLink to="/admin" className="btn">Dashboard</NavLink>
                            ) : (
                                <>
                                    <NavLink to="/marketplace" className="btn">Marketplace</NavLink>
                                    <NavLink to="/activity" className="btn">My Activity</NavLink>
                                    <NavLink to="/profile" className="btn">My Profile</NavLink>
                                </>
                            )}
                            <button onClick={handleLogout} className="btn btn-outline">Logout</button>
                        </div>
                    )}
                </div>
            </nav>
        </header>
    );
};

const AppRoutes = () => {
    const { currentUser } = useContext(AuthContext);
    
    return (
        <div className="app-container">
            <Navbar />
            <main>
                <Routes>
                    <Route path="/" element={<Landing />} />
                    <Route path="/login" element={<Login isAdmin={false} />} />
                    <Route path="/admin-login" element={<Login isAdmin={true} />} />
                    <Route path="/signup" element={<Signup />} />
                    <Route path="/forgot-password" element={<ForgotPassword />} />
                    <Route path="/reset-password/:token" element={<ResetPassword />} />
                    
                    {/* Protected Routes */}
                    <Route path="/marketplace" element={currentUser && !currentUser.isAdmin ? <Marketplace /> : <Navigate to="/login" />} />
                    <Route path="/project/:id" element={currentUser && !currentUser.isAdmin ? <ProjectDetail /> : <Navigate to="/login" />} />
                    <Route path="/profile" element={currentUser && !currentUser.isAdmin ? <Profile /> : <Navigate to="/login" />} />
                    <Route path="/activity" element={currentUser && !currentUser.isAdmin ? <Activity /> : <Navigate to="/login" />} />
                    <Route path="/admin" element={currentUser?.isAdmin ? <AdminDashboard /> : <Navigate to="/admin-login" />} />
                </Routes>
            </main>
            <footer className="footer">
                <div className="container text-sm text-slate-400">© {new Date().getFullYear()} Camp-Link.</div>
            </footer>
        </div>
    );
};

function App() {
    return (
        <AuthProvider>
            <BrowserRouter>
                <AppRoutes />
            </BrowserRouter>
        </AuthProvider>
    );
}

export default App;
