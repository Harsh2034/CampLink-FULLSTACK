import React, { createContext, useState, useEffect } from 'react';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    // Check localStorage for existing user payload (includes token)
    const [currentUser, setCurrentUser] = useState(() => {
        const saved = localStorage.getItem('campLinkUser');
        return saved ? JSON.parse(saved) : null;
    });
    const [theme, setTheme] = useState(localStorage.getItem('theme') || 'dark');
    const [notification, setNotification] = useState(null);

    // Persist login state across browser refreshes
    useEffect(() => {
        if (currentUser) {
            localStorage.setItem('campLinkUser', JSON.stringify(currentUser));
        } else {
            localStorage.removeItem('campLinkUser');
        }
    }, [currentUser]);

    useEffect(() => {
        if (theme === 'light') document.body.classList.add('light-theme');
        else document.body.classList.remove('light-theme');
        localStorage.setItem('theme', theme);
    }, [theme]);

    const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

    const showNotification = (msg) => {
        setNotification(msg);
        setTimeout(() => setNotification(null), 3000);
    };

    // Global Wrapper to automatically attach JWT to all API requests!
    const authFetch = async (url, options = {}) => {
        const headers = { 'Content-Type': 'application/json', ...options.headers };
        if (currentUser?.token) headers['Authorization'] = `Bearer ${currentUser.token}`;
        
        // If the body is explicitly FormData, we must let the browser set the Content-Type to multipart
        if(options.body instanceof FormData) delete headers['Content-Type'];

        return fetch(url, { ...options, headers });
    };

    const login = async (email, password) => {
        try {
            const res = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            if (res.ok) {
                const user = await res.json();
                setCurrentUser(user);
                return user;
            } else {
                showNotification("Invalid Login Credentials");
                return null;
            }
        } catch (error) {
            showNotification("Server Error");
            return null;
        }
    };

    const logout = () => setCurrentUser(null);

    return (
        <AuthContext.Provider value={{ currentUser, setCurrentUser, theme, toggleTheme, login, logout, notification, showNotification, authFetch }}>
            {children}
            <div id="notification" className={notification ? 'show' : ''}>{notification}</div>
        </AuthContext.Provider>
    );
};
