import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Activity = () => {
    const { currentUser, showNotification, authFetch } = useContext(AuthContext);
    const [activeTab, setActiveTab] = useState('projects');
    const [projects, setProjects] = useState([]);
    const [services, setServices] = useState([]);
    const [proposals, setProposals] = useState([]);
    const [users, setUsers] = useState({});
    
    // Proposals View State
    const [viewingProposalsFor, setViewingProposalsFor] = useState(null);
    
    const navigate = useNavigate();

    const fetchAllActivity = async () => {
        try {
            const pRes = await authFetch('/api/projects');
            const sRes = await authFetch('/api/services');
            const prRes = await authFetch('/api/proposals');
            
            const pData = await pRes.json();
            const sData = await sRes.json();
            const prData = await prRes.json();
            
            setProjects(pData);
            setServices(sData);
            setProposals(prData);
            
            const uIds = [...new Set(prData.map(p => p.proposerId))];
            const fetchedUsers = {};
            for (const id of uIds) {
                const uRes = await authFetch(`/api/users/${id}`);
                if (uRes.ok) fetchedUsers[id] = await uRes.json();
            }
            setUsers(fetchedUsers);
            
        } catch (err) {
            console.error(err);
        }
    };

    useEffect(() => {
        fetchAllActivity();
    }, []);

    const handleHire = async (proposalId, projectId) => {
        try {
            await authFetch('/api/hire', {
                method: 'PUT',
                body: JSON.stringify({ proposalId, projectId })
            });
            showNotification('You have hired the student!');
            setViewingProposalsFor(null);
            fetchAllActivity();
        } catch (err) {
            console.error(err);
        }
    };

    const renderMyProjects = () => {
        const myPosted = projects.filter(p => p.postedBy === currentUser.id);
        if (myPosted.length === 0) return <p className="text-sm text-slate-400">You haven't posted any projects yet.</p>;
        
        return myPosted.map(p => {
            const propsCount = proposals.filter(prop => prop.projectId == p.id).length;
            return (
                <div className="card mb-4" key={p.id}>
                    <div className="card-content flex-between">
                        <div>
                            <p className="font-semibold" style={{fontSize: '20px'}}>{p.title}</p>
                            <p className="text-xs text-slate-400 text-left">{propsCount} proposal(s)</p>
                        </div>
                        {p.status === 'Open' ? (
                            <button className="btn btn-outline text-xs" onClick={() => setViewingProposalsFor(p.id)}>View Proposals</button>
                        ) : (
                            <span className="status-badge status-hired">{p.status}</span>
                        )}
                    </div>
                </div>
            );
        });
    };

    const renderMyServices = () => {
        const myPosted = services.filter(s => s.postedBy === currentUser.id);
        if (myPosted.length === 0) return <p className="text-sm text-slate-400">You haven't posted any services yet.</p>;
        
        return myPosted.map(s => (
            <div className="card mb-4" key={s.id}>
                <div className="card-content flex-between">
                    <div>
                        <p className="font-semibold" style={{fontSize: '20px'}}>{s.title}</p>
                        <p className="text-xs text-slate-400 text-left">Price: ₹{s.budget?.toLocaleString()}</p>
                    </div>
                </div>
            </div>
        ));
    };

    const renderMyProposals = () => {
        const mySent = proposals.filter(p => p.proposerId === currentUser.id);
        if (mySent.length === 0) return <p className="text-sm text-slate-400">You haven't sent any proposals yet.</p>;
        
        return mySent.map(p => {
            const listing = projects.find(proj => proj.id == p.projectId) || services.find(serv => serv.id == p.serviceId);
            if (!listing) return null;
            
            return (
                <div className="card mb-4" key={p.id}>
                    <div className="card-content">
                        <p className="font-semibold text-left" style={{fontSize: '20px'}}>{listing.title}</p>
                        <p className="text-xs text-slate-400 text-left mt-1">Your Bid: ₹{p.bid?.toLocaleString()}</p>
                        <p className="text-xs text-slate-400 text-left mt-2">
                            Status: <span className={`font-semibold ${p.status === 'Hired' ? 'text-amber-500' : ''}`}>{p.status}</span>
                        </p>
                    </div>
                </div>
            );
        });
    };

    const renderProposalsList = () => {
        const project = projects.find(p => p.id == viewingProposalsFor);
        const projectProposals = proposals.filter(p => p.projectId == viewingProposalsFor);
        
        return (
            <div>
                <div className="page-header">
                    <button className="btn btn-outline back-btn" onClick={() => setViewingProposalsFor(null)}>← Back</button>
                    <div>
                        <p className="text-sm text-left">Proposals for:</p>
                        <h2 className="section-title">{project?.title}</h2>
                    </div>
                </div>
                {projectProposals.length > 0 ? projectProposals.map(p => {
                    const proposer = users[p.proposerId];
                    return (
                        <div className="card mb-4" key={p.id}>
                            <div className="card-content">
                                <div className="flex-between">
                                    <p className="font-semibold" style={{fontSize: '18px', cursor: 'pointer', color: 'var(--indigo-400)'}} onClick={() => navigate(`/profile`)}>
                                        {proposer?.name || 'Loading...'}
                                    </p>
                                    <p className="text-lg font-semibold">₹{p.bid?.toLocaleString()}</p>
                                </div>
                                <p className="text-sm text-slate-300 mt-2 text-left">{p.coverLetter}</p>
                                <div className="mt-4">
                                    <button className="btn btn-solid" onClick={() => handleHire(p.id, viewingProposalsFor)}>Hire This Student</button>
                                </div>
                            </div>
                        </div>
                    );
                }) : <p className="text-slate-400">No proposals received yet.</p>}
            </div>
        );
    };

    return (
        <div className="page-section">
            <div className="container max-w-5xl">
                {viewingProposalsFor ? (
                    renderProposalsList()
                ) : (
                    <>
                        <div className="page-header">
                            <button className="btn btn-outline back-btn" onClick={() => navigate(-1)}>← Back</button>
                            <h2 className="section-title">My Activity</h2>
                        </div>
                        <div className="tabs mb-4">
                            <button className={`tab ${activeTab === 'projects' ? 'active' : ''}`} onClick={() => setActiveTab('projects')}>My Projects</button>
                            <button className={`tab ${activeTab === 'services' ? 'active' : ''}`} onClick={() => setActiveTab('services')}>My Services</button>
                            <button className={`tab ${activeTab === 'proposals' ? 'active' : ''}`} onClick={() => setActiveTab('proposals')}>My Proposals</button>
                        </div>
                        <div id="activity-content-container">
                            {activeTab === 'projects' && renderMyProjects()}
                            {activeTab === 'services' && renderMyServices()}
                            {activeTab === 'proposals' && renderMyProposals()}
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default Activity;
