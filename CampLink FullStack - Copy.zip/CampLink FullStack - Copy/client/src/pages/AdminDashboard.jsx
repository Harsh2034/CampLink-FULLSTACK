import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';

const AdminDashboard = () => {
    const { showNotification, authFetch } = useContext(AuthContext);
    const [activeTab, setActiveTab] = useState('projects');
    const [listings, setListings] = useState([]);
    const [users, setUsers] = useState({});

    const fetchAdminData = async () => {
        try {
            const res = await authFetch(`/api/${activeTab}`);
            const data = await res.json();
            setListings(data);
            
            const uIds = [...new Set(data.map(d => d.postedBy))];
            const fetchedUsers = { ...users };
            for(const id of uIds) {
                if(!fetchedUsers[id]) {
                    const uRes = await authFetch(`/api/users/${id}`);
                    if(uRes.ok) fetchedUsers[id] = await uRes.json();
                }
            }
            setUsers(fetchedUsers);
            
        } catch (error) {
            console.error(error);
        }
    };

    useEffect(() => {
        fetchAdminData();
    }, [activeTab]);

    const handleDelete = async (itemId) => {
        if(window.confirm('Are you sure you want to delete this listing?')) {
            try {
                await authFetch(`/api/${activeTab}/${itemId}`, { method: 'DELETE' });
                showNotification('Listing deleted successfully.');
                fetchAdminData();
            } catch (error) {
                console.error(error);
            }
        }
    };

    return (
        <div className="page-section">
            <div className="container max-w-5xl">
                <div className="page-header">
                    <h2 className="section-title">Admin Dashboard</h2>
                </div>
                <div className="tabs mb-4">
                    <button className={`tab ${activeTab === 'projects' ? 'active' : ''}`} onClick={() => setActiveTab('projects')}>All Projects</button>
                    <button className={`tab ${activeTab === 'services' ? 'active' : ''}`} onClick={() => setActiveTab('services')}>All Services</button>
                </div>
                <div className="grid md-grid-cols-2 lg-grid-cols-3 gap-6">
                    {listings.map(item => {
                        const poster = users[item.postedBy];
                        
                        return (
                            <div className="card" key={item.id}>
                                <div className="card-content">
                                    <p className="text-sm listing-category">{item.category}</p>
                                    <h3 className="card-title mt-2 text-base" style={{fontSize: '18px'}}>{item.title}</h3>
                                    <p className="text-xs text-slate-400 mt-2">Posted by: {poster?.name || 'Unknown'}</p>
                                </div>
                                <div className="card-content border-t border-slate-800 flex-between" style={{ borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                                    <p className="listing-price text-base" style={{fontSize: '18px'}}>₹{item.budget?.toLocaleString()}</p>
                                    <button className="btn btn-danger text-xs" onClick={() => handleDelete(item.id)}>Delete</button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

export default AdminDashboard;
