import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

const ForgotPassword = () => {
    const [email, setEmail] = useState('');
    const [status, setStatus] = useState(null);
    const [mockLink, setMockLink] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await fetch('/api/forgotpassword', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });
            const data = await res.json();
            if (res.ok) {
                setStatus('success');
                setMockLink(data.resetLink); // Backend sends back the link directly since we aren't using email servers
            } else {
                setStatus(data.error);
            }
        } catch (err) {
            setStatus('Server Error. Ensure Backend is running.');
        }
    };

    return (
        <div className="page-section">
            <div className="container max-w-md">
                <div className="card">
                    <div className="card-header">
                        <h3 className="card-title">Reset Password</h3>
                        <p className="card-subtitle">Enter your email to receive a secure recovery link.</p>
                    </div>
                    <div className="card-content">
                        {status === 'success' ? (
                            <div className="text-center">
                                <p className="text-emerald-500 font-semibold mb-4" style={{fontSize: '18px'}}>Reset link generated successfully!</p>
                                <p className="text-sm text-slate-400 mb-6 text-left">we dont have real email integration<br/><br/>Instead, please click the secure simulated email link below to proceed:</p>
                                <a href={mockLink} className="btn btn-solid w-full" style={{ display: 'block', wordBreak: 'break-all' }}>Proceed to Reset Password</a>
                            </div>
                        ) : (
                            <form onSubmit={handleSubmit} className="form-stack">
                                {status && <p className="text-red-500 text-sm text-center">{status}</p>}
                                <input className="input" type="email" placeholder="you@email.com" required value={email} onChange={e => setEmail(e.target.value)} />
                                <div className="form-actions mt-4">
                                    <button className="btn btn-solid" type="submit" style={{width: '100%'}}>Send Reset Link</button>
                                </div>
                                <p className="text-center text-sm mt-4 text-slate-400">Remembered your password? <Link to="/login" className="link">Log in</Link></p>
                            </form>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ForgotPassword;
