import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Landing = () => {
    const { currentUser } = useContext(AuthContext);

    return (
        <div className="page-section">
            <section className="page-section text-center" style={{ padding: '6rem 0' }}>
                <div className="container">
                    <h1 className="section-title tagline" style={{ fontSize: '3rem', fontWeight: 800 }}>Connect. Collaborate.
                        <span style={{ backgroundImage: 'linear-gradient(to right, var(--indigo-400), var(--fuchsia-400))', backgroundClip: 'text', WebkitBackgroundClip: 'text', color: 'transparent' }}> Build together.</span>
                    </h1>
                    <p className="text-lg" style={{ maxWidth: '42rem', margin: '1.5rem auto 0', color: 'var(--slate-300)' }}>
                        The exclusive freelance marketplace for verified students. Find projects, offer your skills, and build your portfolio within a trusted network.
                    </p>
                    <div className="mt-8">
                        {currentUser ? (
                            <Link to="/marketplace" className="btn btn-solid join_camp">
                                <span id="joining">Enter Campus Network</span>
                            </Link>
                        ) : (
                            <Link to="/signup" className="btn btn-solid join_camp">
                                <span id="joining">Join Your Campus Network</span>
                            </Link>
                        )}
                    </div>
                </div>
            </section>
            
            <section className="page-section" style={{ paddingTop: 0 }}>
                <h2 className="get_now">Claim this now</h2>
                <p id="claim_now">Get these features immediately as You join our platform</p>
                <div className="container grid md-grid-cols-3 gap-4">
                    <div className="card card-content text-center">
                        <div className="font-semibold benefits">2x</div>
                        <div className="text-slate-400 text-sm">Faster team-ups vs. generic groups</div>
                    </div>
                    <div className="card card-content text-center">
                        <div className="benefits font-semibold">24/7</div>
                        <div className="text-slate-400 text-sm">Built-in chat & notifications</div>
                    </div>
                    <div className="card card-content text-center">
                        <div className="benefits font-semibold">City/College</div>
                        <div className="text-slate-400 text-sm">Filter to find the right people</div>
                    </div>
                </div>
            </section>
            
            <section className="page-section">
                <div className="container">
                    <div className="text-center">
                        <h2 className="section-title">What you can do</h2>
                        <p className="section-subtitle">Everything you need to collaborate inside your campus—and nearby colleges.</p>
                    </div>
                    <div className="mt-8 grid md-grid-cols-3 gap-6">
                        {[
                            { title: 'College-based login', desc: 'Upload ID or verify email to access the network.' },
                            { title: 'Profiles that matter', desc: 'Show skills, interests, and availability in a clean card.' },
                            { title: 'Tasks + Chat', desc: 'Post tasks; accept & discuss with built-in chat.' },
                            { title: 'City / College filter', desc: 'Discover peers around you for quick, local turnarounds.' },
                            { title: 'Moderation & Admin', desc: 'Admin console to review users and moderate tasks.' },
                            { title: 'Privacy-first', desc: 'Only verified members can see and interact with tasks.' }
                        ].map((feature, i) => (
                            <div className="card" key={i}>
                                <div className="card-content">
                                    <h3 className="font-semibold features" style={{ fontSize: '20px' }}>{feature.title}</h3>
                                    <p className="text-sm text-slate-300 mt-2">{feature.desc}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Landing;
