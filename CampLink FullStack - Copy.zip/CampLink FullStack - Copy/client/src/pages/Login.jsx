import React, { useState, useContext } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Login = ({ isAdmin }) => {
    const [email, setEmail] = useState(isAdmin ? 'admin@camp-link.com' : 'student@demo.com');
    const [password, setPassword] = useState(isAdmin ? 'adminpass' : 'password123');
    const { login } = useContext(AuthContext);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        const user = await login(email, password);
        if (user) {
            navigate(user.isAdmin ? '/admin' : '/marketplace');
        }
    };

    return (
        <div className="page-section">
            <div className="container max-w-md">
                <div className="card">
                    <div className="card-header">
                        <h3 className="card-title">{isAdmin ? 'Admin Login' : 'Student Login'}</h3>
                    </div>
                    <div className="card-content">
                        <form onSubmit={handleSubmit} className="form-stack">
                            <input className="input" type="email" placeholder={isAdmin ? "admin@camp-link.com" : "you@email.com"} required value={email} onChange={e => setEmail(e.target.value)} />
                            <input className="input" type="password" placeholder="Password" required value={password} onChange={e => setPassword(e.target.value)} />
                            <div className="form-actions">
                                <button className="btn btn-solid" type="submit">
                                    {isAdmin ? 'Login as Admin' : 'Login'}
                                </button>
                                <button className="btn btn-outline back-btn" type="button" onClick={() => navigate(-1)}>Back</button>
                            </div>
                        </form>
                    
                    <p className="text-center text-sm mt-4 text-slate-400">
                        Don't have an account? <Link to="/signup" className="link">Sign up</Link>
                    </p>
                    
                    {!isAdmin && (
                        <p className="text-center text-sm mt-2 text-slate-400">
                            <Link to="/forgot-password" className="link">Forgot your password?</Link>
                        </p>
                    )}
                </div>
            </div>
        </div>
    </div>
    );
};

export default Login;
