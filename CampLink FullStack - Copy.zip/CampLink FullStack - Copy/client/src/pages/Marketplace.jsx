import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Marketplace = () => {
    const { currentUser, showNotification, authFetch } = useContext(AuthContext);
    const [activeTab, setActiveTab] = useState('projects');
    const [searchQuery, setSearchQuery] = useState('');
    const [listings, setListings] = useState([]);
    const [users, setUsers] = useState({});
    
    // Modals state
    const [showPostModal, setShowPostModal] = useState(false);
    const [postType, setPostType] = useState('project');
    const [postForm, setPostForm] = useState({ title: '', description: '', category: '', budget: '', skills: '' });

    const [showContactModal, setShowContactModal] = useState(false);
    
    const navigate = useNavigate();

    const fetchListings = async () => {
        try {
            // Updated to use authFetch
            const res = await authFetch(`/api/${activeTab}`);
            let data = await res.json();
            
            if (activeTab === 'projects') {
                data = data.filter(p => p.status === 'Open');
            }
            
            if (searchQuery) {
                const lowerQ = searchQuery.toLowerCase();
                data = data.filter(item => 
                    item.title.toLowerCase().includes(lowerQ) || 
                    item.description.toLowerCase().includes(lowerQ) || 
                    item.category.toLowerCase().includes(lowerQ)
                );
            }
            setListings(data);
            
            const uniqueUserIds = [...new Set(data.map(item => item.postedBy))];
            const fetchedUsers = { ...users };
            for (const id of uniqueUserIds) {
                if (!fetchedUsers[id]) {
                    const uRes = await authFetch(`/api/users/${id}`);
                    if (uRes.ok) fetchedUsers[id] = await uRes.json();
                }
            }
            setUsers(fetchedUsers);
            
        } catch (err) {
            console.error(err);
        }
    };

    useEffect(() => {
        fetchListings();
    }, [activeTab, searchQuery]);

    const handlePostSubmit = async (e) => {
        e.preventDefault();
        const payload = {
            ...postForm,
            budget: parseInt(postForm.budget),
            postedBy: currentUser.id,
            skills: postForm.skills.split(',').map(s => s.trim()).filter(Boolean)
        };
        
        try {
            // Protected route via authFetch
            await authFetch(`/api/${postType}s`, {
                method: 'POST',
                body: JSON.stringify(payload)
            });
            showNotification('Listing posted successfully!');
            setShowPostModal(false);
            setPostForm({ title: '', description: '', category: '', budget: '', skills: '' });
            setActiveTab(`${postType}s`);
            fetchListings();
        } catch(err) {
            console.error(err);
        }
    };

    return (
        <div className="page-section">
            <div className="container" style={{maxWidth: '1440px'}}>
                <header className="marketplace-header">
                    <div className="tabs">
                        <button className={`tab ${activeTab === 'projects' ? 'active' : ''}`} onClick={() => setActiveTab('projects')}>Browse Projects</button>
                        <button className={`tab ${activeTab === 'services' ? 'active' : ''}`} onClick={() => setActiveTab('services')}>Browse Services</button>
                    </div>
                    <div className="marketplace-actions">
                        <input className="input search-bar" placeholder="Search..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
                        <button className="btn btn-solid" onClick={() => setShowPostModal(true)}>Post New...</button>
                    </div>
                </header>
                
                <div className="grid md-grid-cols-2 lg-grid-cols-3 gap-6">
                    {listings.map(item => {
                        const isProject = activeTab === 'projects';
                        const isOwn = item.postedBy === currentUser.id;
                        const poster = users[item.postedBy];
                        
                        return (
                            <div className="card listing-card" key={item.id} onClick={(e) => {
                                if(e.target.tagName !== 'BUTTON') {
                                    if(isProject) navigate(`/project/${item.id}`);
                                }
                            }}>
                                <div className="card-content">
                                    <p className="text-sm listing-category">{item.category}</p>
                                    <h3 className="card-title mt-2">{item.title}</h3>
                                    <div style={{display: 'flex', alignItems: 'center', gap: '0.75rem', marginTop: '0.75rem'}}>
                                        <div style={{width: '32px', height: '32px', borderRadius: '50%', backgroundColor: isOwn ? 'var(--emerald-500)' : 'var(--indigo-500)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '14px', fontWeight: 'bold', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'}}>
                                            {isOwn ? 'U' : (poster?.name ? poster.name.charAt(0).toUpperCase() : '?')}
                                        </div>
                                        <div style={{display: 'flex', flexDirection: 'column'}}>
                                            <span className="text-slate-400" style={{fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '0.05em', lineHeight: '1'}}>Posted By</span>
                                            <span style={{color: 'var(--slate-200)', fontWeight: '600', fontSize: '0.875rem', lineHeight: '1', marginTop: '0.25rem'}}>{isOwn ? 'You' : poster?.name}</span>
                                        </div>
                                    </div>
                                    <p className="text-sm text-slate-300 mt-4 card-description">{item.description}</p>
                                    <div className="card-skills-container">
                                        {(item.skills || []).map(skill => <span key={skill} className="skill-tag-sm">{skill}</span>)}
                                    </div>
                                </div>
                                <div className="card-content border-t border-slate-800 flex-between" style={{ borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                                    <p className="listing-price">₹{item.budget.toLocaleString()} <span>{isProject ? 'Budget' : 'Price'}</span></p>
                                    {!isOwn ? (
                                        isProject ? (
                                            <span className="status-badge status-open">{item.status}</span>
                                        ) : (
                                            <button className="btn btn-outline text-xs" onClick={(e) => { e.stopPropagation(); setShowContactModal(true); }}>Contact</button>
                                        )
                                    ) : (
                                        <span>Posted by you</span>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            {showPostModal && (
                <div className="modal-overlay active" onClick={() => setShowPostModal(false)}>
                    <div className="modal-content" onClick={e => e.stopPropagation()}>
                        <button className="modal-close-btn" onClick={() => setShowPostModal(false)}>&times;</button>
                        <h3 className="card-title mb-4">Create a New Listing</h3>
                        <form className="form-stack" onSubmit={handlePostSubmit}>
                            <div className="toggle-group">
                                <button type="button" className={`toggle-btn ${postType === 'project' ? 'active' : ''}`} onClick={() => setPostType('project')}>Post a Project</button>
                                <button type="button" className={`toggle-btn ${postType === 'service' ? 'active' : ''}`} onClick={() => setPostType('service')}>Offer a Service</button>
                            </div>
                            <input className="input" placeholder="Title" required value={postForm.title} onChange={e => setPostForm({...postForm, title: e.target.value})} />
                            <textarea className="textarea" placeholder="Description..." required value={postForm.description} onChange={e => setPostForm({...postForm, description: e.target.value})}></textarea>
                            <input className="input" placeholder="Category" required value={postForm.category} onChange={e => setPostForm({...postForm, category: e.target.value})} />
                            <input className="input" type="number" placeholder="Budget/Price in ₹" required value={postForm.budget} onChange={e => setPostForm({...postForm, budget: e.target.value})} />
                            <input className="input" placeholder="Skills (comma-separated)" required value={postForm.skills} onChange={e => setPostForm({...postForm, skills: e.target.value})} />
                            <div className="mt-2"><button className="btn btn-solid" type="submit">Post Listing</button></div>
                        </form>
                    </div>
                </div>
            )}

            {showContactModal && (
                <div className="modal-overlay active" onClick={() => setShowContactModal(false)}>
                    <div className="modal-content" onClick={e => e.stopPropagation()}>
                        <button className="modal-close-btn" onClick={() => setShowContactModal(false)}>&times;</button>
                        <h3 className="card-title mb-4">Contact Seller</h3>
                        <form className="form-stack" onSubmit={(e) => { e.preventDefault(); showNotification('Message sent!'); setShowContactModal(false); }}>
                            <input className="input" type="email" placeholder="Your Email Address" required />
                            <textarea className="textarea" placeholder="Your message..." required></textarea>
                            <button className="btn btn-solid" type="submit">Send Message</button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Marketplace;
