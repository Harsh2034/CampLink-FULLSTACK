import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Profile = ({ userId }) => {
    const { currentUser, setCurrentUser, showNotification, authFetch } = useContext(AuthContext);
    const [user, setUser] = useState(null);
    const [isEditing, setIsEditing] = useState(false);
    const [newSkill, setNewSkill] = useState('');
    const navigate = useNavigate();

    const targetUserId = userId || currentUser.id;
    const isOwnProfile = currentUser && currentUser.id === targetUserId;

    useEffect(() => {
        const fetchUser = async () => {
            const res = await authFetch(`/api/users/${targetUserId}`);
            if(res.ok) {
                const data = await res.json();
                setUser(data);
            }
        };
        fetchUser();
    }, [targetUserId]);

    const handleSave = async () => {
        try {
            await authFetch(`/api/users/${currentUser.id}`, {
                method: 'PUT',
                body: JSON.stringify(user)
            });
            setCurrentUser(user);
            setIsEditing(false);
            showNotification("Profile saved!");
        } catch (error) {
            console.error(error);
        }
    };

    const addSkill = async (e) => {
        e.preventDefault();
        if (newSkill.trim()) {
            const updatedSkills = [...(user.skills || []), newSkill.trim()];
            const updatedUser = { ...user, skills: updatedSkills };
            setUser(updatedUser);
            setNewSkill('');
            
            await authFetch(`/api/users/${currentUser.id}`, {
                method: 'PUT',
                body: JSON.stringify({ skills: updatedSkills })
            });
            setCurrentUser(updatedUser);
        }
    };

    const removeSkill = async (skillToRemove) => {
        const updatedSkills = user.skills.filter(s => s !== skillToRemove);
        const updatedUser = { ...user, skills: updatedSkills };
        setUser(updatedUser);
        
        await authFetch(`/api/users/${currentUser.id}`, {
            method: 'PUT',
            body: JSON.stringify({ skills: updatedSkills })
        });
        setCurrentUser(updatedUser);
    };

    if (!user) return <div className="container page-section text-center">Loading...</div>;

    return (
        <div className="page-section">
            <div className="container max-w-3xl">
                <div className="page-header">
                    <button className="btn btn-outline back-btn" onClick={() => navigate(-1)}>← Back</button>
                    <div className="flex-between" style={{ width: '100%' }}>
                        <h2 className="section-title">{isOwnProfile ? 'My Profile' : `${user.name}'s Profile`}</h2>
                        {isOwnProfile && (
                            <button className="btn btn-outline" onClick={() => isEditing ? handleSave() : setIsEditing(true)}>
                                {isEditing ? 'Save Changes' : 'Edit Profile'}
                            </button>
                        )}
                    </div>
                </div>
                <div className="card">
                    <div className="card-content form-stack">
                        <div>
                            <label className="form-label">Full Name</label>
                            <input className="input" value={user.name || ''} onChange={e => setUser({...user, name: e.target.value})} disabled={!isEditing} />
                        </div>
                        <div className="mt-4">
                            <label className="form-label">College</label>
                            <input className="input" value={user.college || ''} onChange={e => setUser({...user, college: e.target.value})} disabled={!isEditing} />
                        </div>
                        <div className="grid md-grid-cols-2 gap-4 mt-4">
                            <div>
                                <label className="form-label">Year</label>
                                <input className="input" value={user.year || ''} onChange={e => setUser({...user, year: e.target.value})} disabled={!isEditing} />
                            </div>
                            <div>
                                <label className="form-label">Branch</label>
                                <input className="input" value={user.branch || ''} onChange={e => setUser({...user, branch: e.target.value})} disabled={!isEditing} />
                            </div>
                        </div>
                        <div className="mt-4">
                            <label className="form-label">Bio</label>
                            <textarea className="textarea" value={user.bio || ''} onChange={e => setUser({...user, bio: e.target.value})} disabled={!isEditing}></textarea>
                        </div>
                        <div className="mt-4">
                            <label className="form-label">Skills</label>
                            <div className="skills-container">
                                {user.skills?.map(skill => (
                                    <span className="skill-tag" key={skill}>
                                        {skill}
                                        {isEditing && (
                                            <button className="skill-remove-btn" type="button" onClick={() => removeSkill(skill)}>&times;</button>
                                        )}
                                    </span>
                                ))}
                            </div>
                        </div>
                        {isEditing && (
                            <div>
                                <hr className="border-slate-700 my-4" />
                                <form onSubmit={addSkill} className="flex gap-2" style={{ display: 'flex', gap: '0.5rem' }}>
                                    <input className="input" placeholder="Add a new skill" value={newSkill} onChange={e => setNewSkill(e.target.value)} />
                                    <button type="submit" className="btn btn-solid">Add</button>
                                </form>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Profile;
