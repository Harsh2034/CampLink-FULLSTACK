import React, { useState, useEffect, useContext } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const ProjectDetail = () => {
    const { id } = useParams();
    const { currentUser, showNotification, authFetch } = useContext(AuthContext);
    const navigate = useNavigate();
    const [project, setProject] = useState(null);
    const [client, setClient] = useState(null);
    const [proposals, setProposals] = useState([]);
    const [users, setUsers] = useState({});
    
    // Proposal Modal
    const [showProposalModal, setShowProposalModal] = useState(false);
    const [bid, setBid] = useState('');
    const [coverLetter, setCoverLetter] = useState('');

    const fetchAllData = async () => {
        const res = await authFetch('/api/projects');
        const projects = await res.json();
        const p = projects.find(proj => proj._id === id || proj.id == id);
        setProject(p);
        
        if (p) {
            const cRes = await authFetch(`/api/users/${p.postedBy}`);
            if (cRes.ok) setClient(await cRes.json());
            
            // If the viewer is the project owner, fetch the proposals!
            if (p.postedBy === currentUser?.id) {
                const propRes = await authFetch('/api/proposals');
                if (propRes.ok) {
                    const allProposals = await propRes.json();
                    const relevantProposals = allProposals.filter(pr => pr.projectId === p._id || pr.projectId == id);
                    setProposals(relevantProposals);
                    
                    // Fetch users for those proposals logically
                    const newUsers = {};
                    for (const pr of relevantProposals) {
                        if (!newUsers[pr.proposerId]) {
                            const uRes = await authFetch(`/api/users/${pr.proposerId}`);
                            if (uRes.ok) newUsers[pr.proposerId] = await uRes.json();
                        }
                    }
                    setUsers(newUsers);
                }
            }
        }
    };

    useEffect(() => {
        fetchAllData();
    }, [id, currentUser]);

    const handleApply = async (e) => {
        e.preventDefault();
        try {
            await authFetch('/api/proposals', {
                method: 'POST',
                body: JSON.stringify({
                    proposerId: currentUser.id,
                    projectId: project.id,
                    bid: parseInt(bid),
                    coverLetter: coverLetter
                })
            });
            showNotification('Proposal submitted successfully!');
            setShowProposalModal(false);
            setBid('');
            setCoverLetter('');
            navigate('/activity');
        } catch(err) {
            console.error(err);
        }
    };

    if (!project) return <div className="page-section text-center">Loading...</div>;

    const isOwn = project.postedBy === currentUser?.id;

    return (
        <div className="page-section">
            <div className="container max-w-3xl">
                <div className="page-header">
                    <button className="btn btn-outline back-btn" onClick={() => navigate(-1)}>← Back</button>
                    <div>
                        <p className="text-sm text-sky-400">{project.category}</p>
                        <h2 className="section-title mt-2">{project.title}</h2>
                        <p className="text-sm text-slate-400 mt-2">
                            {isOwn ? 'Posted by you' : <>Posted by <Link to="/profile" className="link">{client?.name}</Link></>}
                        </p>
                    </div>
                    <span className={`status-badge ${project.status === 'Open' ? 'status-open' : 'status-hired'}`}>{project.status}</span>
                </div>
                
                <div className="card">
                    <div className="card-content">
                        <h3 className="font-semibold mb-2" style={{fontSize: '20px'}}>Project Description</h3>
                        <p className="text-slate-300">{project.description}</p>
                        
                        <h3 className="font-semibold mt-4 mb-2" style={{fontSize: '20px'}}>Skills Required</h3>
                        <div className="card-skills-container">
                            {(project.skills || []).map(skill => <span key={skill} className="skill-tag-sm">{skill}</span>)}
                        </div>
                        
                        <h3 className="font-semibold mt-4 mb-2" style={{fontSize: '20px'}}>Budget</h3>
                        <p className="listing-price">₹{project.budget.toLocaleString()}</p>
                    </div>
                </div>
                
                {!isOwn && project.status === 'Open' && !currentUser.isAdmin && (
                    <div className="mt-8">
                        <button className="btn btn-solid" onClick={() => setShowProposalModal(true)}>Apply Now</button>
                    </div>
                )}

                {isOwn && proposals.length > 0 && (
                    <div className="mt-8">
                        <h3 className="font-semibold mb-4" style={{fontSize: '20px'}}>Submitted Proposals ({proposals.length})</h3>
                        <div className="form-stack">
                            {proposals.map(pr => {
                                const proposer = users[pr.proposerId];
                                const isHired = pr.status === 'Hired';
                                
                                return (
                                    <div key={pr._id || pr.id} className="card" style={{borderColor: isHired ? 'var(--emerald-500)' : 'rgba(255,255,255,0.1)'}}>
                                        <div className="card-content">
                                            <div className="flex-between mb-2">
                                                <div style={{display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
                                                    <div style={{width: '32px', height: '32px', borderRadius: '50%', backgroundColor: 'var(--indigo-500)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '14px', fontWeight: 'bold'}}>
                                                        {proposer?.name ? proposer.name.charAt(0).toUpperCase() : '?'}
                                                    </div>
                                                    <div>
                                                        <p className="font-semibold">{proposer?.name || 'Loading Student...'}</p>
                                                        <p className="text-xs text-slate-400">Bid: <span className="text-emerald-400 font-semibold">₹{pr.bid?.toLocaleString()}</span></p>
                                                    </div>
                                                </div>
                                                {project.status === 'Open' && !isHired && (
                                                    <button className="btn btn-outline" style={{borderColor: 'var(--emerald-500)', color: 'var(--emerald-500)'}} onClick={async () => {
                                                        try {
                                                            const res = await authFetch('/api/hire', {
                                                                method: 'PUT',
                                                                headers: { 'Content-Type': 'application/json' },
                                                                body: JSON.stringify({ proposalId: pr._id || pr.id, projectId: project._id || project.id })
                                                            });
                                                            if (res.ok) {
                                                                showNotification(`Successfully hired ${proposer?.name}!`);
                                                                fetchAllData(); // Automatically reflect state changes
                                                            } else { showNotification('Failed to hire. See Logs.'); }
                                                        } catch(e) { console.error(e); }
                                                    }}>Accept Proposal</button>
                                                )}
                                                {isHired && <span className="status-badge status-hired" style={{fontSize: '14px', backgroundColor: 'var(--emerald-500)', color: 'white'}}>HIRED ✓</span>}
                                            </div>
                                            <p className="text-sm text-slate-300 mt-4" style={{padding: '1rem', backgroundColor: 'rgba(0,0,0,0.2)', borderRadius: '0.5rem', textAlign: 'left'}}>{pr.coverLetter}</p>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}
            </div>

            {showProposalModal && (
                <div className="modal-overlay active" onClick={() => setShowProposalModal(false)}>
                    <div className="modal-content" onClick={e => e.stopPropagation()}>
                        <button className="modal-close-btn" onClick={() => setShowProposalModal(false)}>&times;</button>
                        <h3 className="card-title mb-4">Submit Your Proposal</h3>
                        <form className="form-stack" onSubmit={handleApply}>
                            <textarea className="textarea" placeholder="Write a short message explaining what you offer..." required value={coverLetter} onChange={e => setCoverLetter(e.target.value)}></textarea>
                            <input className="input" type="number" placeholder="Your bid in ₹" required value={bid} onChange={e => setBid(e.target.value)} />
                            <button className="btn btn-solid" type="submit">Submit Proposal</button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ProjectDetail;
