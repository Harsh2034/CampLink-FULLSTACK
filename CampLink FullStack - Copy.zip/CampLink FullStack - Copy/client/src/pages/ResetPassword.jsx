import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const ResetPassword = () => {
    const { token } = useParams(); // Automatically extracts the /reset-password/:token from the URL!
    const navigate = useNavigate();
    const [password, setPassword] = useState('');
    const [confirm, setConfirm] = useState('');
    const [status, setStatus] = useState(null);
    const [success, setSuccess] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (password !== confirm) return setStatus("Passwords do not match!");
        
        try {
            const res = await fetch(`/api/resetpassword/${token}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ password })
            });
            const data = await res.json();
            if (res.ok) {
                setSuccess(true);
            } else {
                setStatus(data.error);
            }
        } catch (err) {
            setStatus('Server Error');
        }
    };

    if (success) {
        return (
            <div className="page-section">
                <div className="container max-w-md text-center">
                    <h2 className="section-title text-emerald-500">Password Updated!</h2>
                    <p className="text-slate-400 mt-4">Your password has been successfully reset securely. You can now log into your account using the new credentials.</p>
                    <div className="mt-8"><button onClick={() => navigate('/login')} className="btn btn-solid">Go to Login</button></div>
                </div>
            </div>
        );
    }

    return (
        <div className="page-section">
            <div className="container max-w-md">
                <div className="card">
                    <div className="card-header">
                        <h3 className="card-title">Create New Password</h3>
                        <p className="card-subtitle">Choose a strong, new password for your account.</p>
                    </div>
                    <div className="card-content">
                        <form onSubmit={handleSubmit} className="form-stack">
                            {status && <p className="text-red-500 text-sm text-center">{status}</p>}
                            <input className="input" type="password" placeholder="New Password" required minLength="6" value={password} onChange={e => setPassword(e.target.value)} />
                            <input className="input" type="password" placeholder="Confirm Password" required minLength="6" value={confirm} onChange={e => setConfirm(e.target.value)} />
                            <div className="form-actions mt-4">
                                <button className="btn btn-solid" type="submit" style={{width: '100%'}}>Save Password</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ResetPassword;
