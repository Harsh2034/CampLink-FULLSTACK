import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Signup = () => {
    const { setCurrentUser, showNotification } = useContext(AuthContext);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [file, setFile] = useState(null);
    const [submitted, setSubmitted] = useState(false);
    
    // Additional fields our backend supports explicitly
    const [college, setCollege] = useState('');
    const [year, setYear] = useState('');
    const [branch, setBranch] = useState('');

    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        try {
            const res = await fetch('/api/signup', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password, college, year, branch })
            });
            
            if (res.ok) {
                const user = await res.json();
                setCurrentUser(user);
                showNotification("Account successfully created!");
                setSubmitted(true);
            } else {
                const err = await res.json();
                showNotification(err.error || "Signup Failed");
            }
        } catch (error) {
            showNotification("Server Error. Make sure Backend is running.");
        }
    };

    if (submitted) {
        return (
            <div className="page-section">
                <div className="container max-w-md text-center">
                    <h2 className="section-title">Registration Complete!</h2>
                    <p className="text-slate-400 mt-4">Your College ID has been uploaded for verification, but we have granted you immediate conditional access.</p>
                    <div className="mt-8">
                        <button onClick={() => navigate('/marketplace')} className="btn btn-solid">Enter Marketplace</button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="page-section">
            <div className="container max-w-md">
                <div className="card">
                    <div className="card-header">
                        <h3 className="card-title">Create Account</h3>
                        <p className="card-subtitle">Join the exclusive network for student freelancers.</p>
                    </div>
                    <div className="card-content">
                        <form onSubmit={handleSubmit} className="form-stack">
                            <input className="input" placeholder="Full Name" required value={name} onChange={e => setName(e.target.value)} />
                            <input className="input" type="email" placeholder="you@email.com" required value={email} onChange={e => setEmail(e.target.value)} />
                            <input className="input" type="password" placeholder="Create Password" required minLength="6" value={password} onChange={e => setPassword(e.target.value)} />
                            
                            <div className="grid md-grid-cols-2 gap-4 mt-2">
                                <input className="input" placeholder="College Name" value={college} onChange={e => setCollege(e.target.value)} />
                                <input className="input" placeholder="Branch / Major" value={branch} onChange={e => setBranch(e.target.value)} />
                            </div>
                            
                            <div className="mt-2">
                                <label className="form-label" htmlFor="college-id-upload">Upload College ID (Verification)</label>
                                <input id="college-id-upload" className="input" type="file" required onChange={e => setFile(e.target.files[0])} />
                                {file && <p className="text-xs text-slate-400 mt-2">Selected: {file.name}</p>}
                            </div>
                            <div className="form-actions mt-4">
                                <button className="btn btn-solid" type="submit">Create Account</button>
                                <button className="btn btn-outline back-btn" type="button" onClick={() => navigate(-1)}>Back</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Signup;
