const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        // Fallback to explicit string if .env doesn't load correctly based on terminal launch folder
        const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/camplink';
        const conn = await mongoose.connect(uri);
        console.log(`✅ Connected to MongoDB locally! (Database: ${conn.connection.name})`);
    } catch (err) {
        console.error('❌ MongoDB connection error:', err.message);
        console.error('Make sure you have installed MongoDB Community Server and that it is running!');
        process.exit(1);
    }
};

module.exports = connectDB;
