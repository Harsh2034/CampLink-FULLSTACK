const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
    // Look for Authorization header from React frontend
    const authHeader = req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'No token, authorization denied' });
    }

    // Extract the JWT string
    const token = authHeader.split(' ')[1];

    try {
        // Verify mathematically
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded; // Contains the logged-in user's ID
        next();
    } catch (err) {
        res.status(401).json({ error: 'Token is not valid' });
    }
};

module.exports = authMiddleware;
