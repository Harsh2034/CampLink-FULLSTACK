const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
    _id: { type: String, default: () => new mongoose.Types.ObjectId().toString() },
    title: { type: String, required: true },
    postedBy: { type: String, required: true }, // Simple String for now, mapped during seed
    category: { type: String, required: true },
    description: { type: String, required: true },
    budget: { type: Number, required: true },
    status: { type: String, enum: ['Open', 'Hired'], default: 'Open' },
    skills: [String]
}, { timestamps: true });

// Ensure JSON output matches legacy React frontend expectations
projectSchema.set('toJSON', {
    virtuals: true,
    versionKey: false,
    transform: function (doc, ret) {
        delete ret._id;
    }
});

module.exports = mongoose.model('Project', projectSchema);
