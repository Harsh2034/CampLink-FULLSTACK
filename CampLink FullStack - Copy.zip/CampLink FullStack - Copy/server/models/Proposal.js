const mongoose = require('mongoose');

const proposalSchema = new mongoose.Schema({
    _id: { type: String, default: () => new mongoose.Types.ObjectId().toString() },
    projectId: { type: String },
    serviceId: { type: String },
    proposerId: { type: String, required: true },
    bid: { type: Number, required: true },
    coverLetter: { type: String, required: true },
    status: { type: String, enum: ['Submitted', 'Hired', 'Rejected'], default: 'Submitted' }
}, { timestamps: true });

// Ensure JSON output matches legacy React frontend expectations
proposalSchema.set('toJSON', {
    virtuals: true,
    versionKey: false,
    transform: function (doc, ret) {
        delete ret._id;
    }
});

module.exports = mongoose.model('Proposal', proposalSchema);
