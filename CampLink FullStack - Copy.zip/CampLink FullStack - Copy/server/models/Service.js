const mongoose = require('mongoose');

const serviceSchema = new mongoose.Schema({
    _id: { type: String, default: () => new mongoose.Types.ObjectId().toString() },
    title: { type: String, required: true },
    postedBy: { type: String, required: true },
    category: { type: String, required: true },
    description: { type: String, required: true },
    budget: { type: Number, required: true },
    skills: [String]
}, { timestamps: true });

// Ensure JSON output matches legacy React frontend expectations
serviceSchema.set('toJSON', {
    virtuals: true,
    versionKey: false,
    transform: function (doc, ret) {
        delete ret._id;
    }
});

module.exports = mongoose.model('Service', serviceSchema);
