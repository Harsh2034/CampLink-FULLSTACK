require('dotenv').config();
const mongoose = require('mongoose');
const fs = require('fs');
const User = require('./models/User');
const Project = require('./models/Project');
const Service = require('./models/Service');
const Proposal = require('./models/Proposal');
const connectDB = require('./database');

async function seed() {
    await connectDB();
    const data = JSON.parse(fs.readFileSync('../data.json', 'utf8'));

    console.log('Clearing existing MongoDB data...');
    await User.deleteMany();
    await Project.deleteMany();
    await Service.deleteMany();
    await Proposal.deleteMany();

    console.log('Seeding legacy flat-file data into MongoDB...');
    for(const u of data.users) {
        await User.create({
            _id: String(u.id), 
            name: u.name,
            email: u.email,
            password: u.password,
            college: u.college,
            year: u.year,
            branch: u.branch,
            bio: u.bio,
            skills: u.skills,
            isAdmin: u.isAdmin
        });
    }

    for(const p of data.projects) {
        await Project.create({
            _id: String(p.id),
            title: p.title,
            postedBy: String(p.postedBy),
            category: p.category,
            description: p.description,
            budget: p.budget,
            status: p.status,
            skills: p.skills
        });
    }

    for(const s of data.services) {
        await Service.create({
            _id: String(s.id),
            title: s.title,
            postedBy: String(s.postedBy),
            category: s.category,
            description: s.description,
            budget: s.budget,
            skills: s.skills
        });
    }

    for(const p of data.proposals) {
        await Proposal.create({
            _id: String(p.id),
            projectId: String(p.projectId),
            proposerId: String(p.proposerId),
            bid: p.bid,
            status: p.status,
            coverLetter: p.coverLetter
        });
    }

    console.log('✅ Legacy Data Seeded into MongoDB Successfully!');
    process.exit();
}

seed();
