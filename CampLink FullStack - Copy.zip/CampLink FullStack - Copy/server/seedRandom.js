require('dotenv').config();
const mongoose = require('mongoose');
const Project = require('./models/Project');
const Service = require('./models/Service');
const connectDB = require('./database');

const randomProjects = [
    {
        title: "Need a React native developer for a fitness app",
        postedBy: "1", // Assigned to your first seeded user
        category: "Software Development",
        description: "I have a big idea for a campus fitness tracker but absolutely zero mobile development skills. I need a solid React Native dev to build out 3 primary screens (Dashboard, Workouts, Profile). Must be responsive!",
        budget: 5000,
        status: "Open",
        skills: ["React Native", "Javascript", "UI/UX"]
    },
    {
        title: "Looking for a Graphic Designer for Spring Fest Poster",
        postedBy: "2", // Assigned to Priya
        category: "Design",
        description: "The music club is hosting an electric music festival next month. We need eye-catching, cyberpunk-styled A3 posters and some Instagram square variants. Creativity is absolutely necessary.",
        budget: 1500,
        status: "Open",
        skills: ["Photoshop", "Illustrator", "Event Design"]
    },
    {
        title: "Tutor needed for Data Structures and Algorithms",
        postedBy: "1",
        category: "Tutoring",
        description: "I am struggling heavily with Dynamic Programming and Graph traversing algorithms for my upcoming midterm. Need someone who can explain things with patience and visual examples. Available evenings.",
        budget: 800,
        status: "Open",
        skills: ["Algorithms", "C++", "Java"]
    },
    {
        title: "Video Editor needed for Short Film",
        postedBy: "3", // Assigned to third user from data.json
        category: "Media",
        description: "Shot a 10-minute psychological thriller for my Film Studies class. I have all the raw footage. Need someone to do the cutting, basic colour grading, and add some intense royalty-free background music.",
        budget: 3500,
        status: "Open",
        skills: ["Premiere Pro", "Color Grading", "Audio"]
    },
    {
        title: "Machine Learning model debugging",
        postedBy: "2",
        category: "Software Development",
        description: "My PyTorch Convolutional Neural Network keeps overfitting to my training image data and I can't figure out why. Will pay someone to hop on a zoom call, look at my notebook, and fix my layers/dropouts.",
        budget: 2000,
        status: "Open",
        skills: ["Python", "PyTorch", "Deep Learning"]
    }
];

const randomServices = [
    {
        title: "I will build you a beautiful personal portfolio website",
        postedBy: "2",
        category: "Software Development",
        description: "Every student needs a personal portfolio to get internships. I will build you a very fast, responsive, modern single-page website using React. I'll host it for you on Vercel for free forever.",
        budget: 2500,
        skills: ["React", "CSS", "Frontend"]
    },
    {
        title: "Professional Resume Formatting and Review",
        postedBy: "3",
        category: "Career",
        description: "Is your resume getting auto-rejected by ATS parsers? I will reformat your messy word document into a sleek, professional, ATS-friendly PDF template that stands out to recruiters.",
        budget: 500,
        skills: ["Writing", "Formatting", "Career Advice"]
    },
    {
        title: "I offer Python automation & web scraping scripts",
        postedBy: "1",
        category: "Software Development",
        description: "Doing boring data entry or trying to track prices across websites? I will write you a custom Python script using BeautifulSoup or Selenium to automatically scrape the data you need and dump it into Excel.",
        budget: 1200,
        skills: ["Python", "Web Scraping", "Automation"]
    },
    {
        title: "I will proofread and edit your final essays",
        postedBy: "4",
        category: "Writing",
        description: "I am an English major offering heavy structural editing and grammar checks for your term papers. I make sure your argument flows smoothly and your citations are perfectly formatted in APA or MLA.",
        budget: 400,
        skills: ["Editing", "Research", "Grammar"]
    },
    {
        title: "I will mix and master your music tracks",
        postedBy: "1",
        category: "Media",
        description: "Are your campus band recordings sounding muddy or quiet? Send me the stems and I will expertly EQ, compress, mix, and master them until they sound radio-ready loud and clear.",
        budget: 1800,
        skills: ["Ableton", "FL Studio", "Audio Engineering"]
    }
];

async function seedRandomData() {
    await connectDB();
    
    console.log('Injecting 5 Random Projects...');
    for(const proj of randomProjects) {
        await Project.create(proj);
    }

    console.log('Injecting 5 Random Services...');
    for(const serv of randomServices) {
        await Service.create(serv);
    }

    console.log('✅ 10 pieces of new random data successfully injected into MongoDB!');
    process.exit();
}

seedRandomData();
