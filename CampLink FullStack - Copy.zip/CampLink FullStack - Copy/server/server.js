require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');

const connectDB = require('./database');
const User = require('./models/User');
const Project = require('./models/Project');
const Service = require('./models/Service');
const Proposal = require('./models/Proposal');
const auth = require('./middleware/auth');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Intialize MongoDB Connection
connectDB();

// ============================================
// PUBLIC ROUTES (No JWT required)
// ============================================

app.get('/api/projects', async (req, res) => {
    try {
        const projects = await Project.find().sort({ createdAt: -1 });
        res.json(projects);
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

app.get('/api/services', async (req, res) => {
    try {
        const services = await Service.find().sort({ createdAt: -1 });
        res.json(services);
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

app.get('/api/proposals', async (req, res) => {
    try {
        const proposals = await Proposal.find().sort({ createdAt: -1 });
        res.json(proposals);
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

app.get('/api/users/:id', async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) return res.status(404).json({ error: 'User not found' });
        res.json(user);
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

// ============================================
// AUTHENTICATION ROUTES
// ============================================

app.post('/api/signup', async (req, res) => {
    try {
        const { name, email, password, college, year, branch, bio, skills } = req.body;
        
        // Check if email already exists
        let user = await User.findOne({ email });
        if (user) return res.status(400).json({ error: 'User already exists' });
        
        // Create new user (Bcrypt intercepts and hashes the password automatically!)
        user = new User({ name, email, password, college, year, branch, bio, skills });
        await user.save();
        
        // Generate Token immediately to log them in
        const token = jwt.sign(
            { id: user._id, isAdmin: user.isAdmin },
            process.env.JWT_SECRET,
            { expiresIn: '1d' }
        );
        
        const userJSON = user.toJSON();
        userJSON.token = token;
        
        res.status(201).json(userJSON);
    } catch (err) { 
        console.error('CRITICAL BACKEND ERROR ON SIGNUP:', err);
        res.status(500).json({ error: 'Server Error', details: err.message }); 
    }
});

const crypto = require('crypto');

app.post('/api/forgotpassword', async (req, res) => {
    try {
        const { email } = req.body;
        const user = await User.findOne({ email });
        if (!user) return res.status(404).json({ error: 'No account with that email address exists.' });

        // Mathematically secure temporary 40-character hex string
        const token = crypto.randomBytes(20).toString('hex');
        
        user.resetPasswordToken = token;
        user.resetPasswordExpires = Date.now() + 15 * 60 * 1000; // Lives for 15 minutes
        await user.save();

        res.json({ 
            message: 'Reset link generated successfully.', 
            resetLink: `http://localhost:5173/reset-password/${token}` 
        });
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

app.post('/api/resetpassword/:token', async (req, res) => {
    try {
        // Find user by EXACT token and ensure the clock hasn't passed the expiry date
        const user = await User.findOne({
            resetPasswordToken: req.params.token,
            resetPasswordExpires: { $gt: Date.now() }
        });

        if (!user) return res.status(400).json({ error: 'Password reset token is invalid or has expired.' });

        // Overwrite password. Our Mongoose pre('save') hook dynamically sweeps in and Bcrypts it!
        user.password = req.body.password;
        
        // Strip the single-use token from the database
        user.resetPasswordToken = undefined;
        user.resetPasswordExpires = undefined;
        await user.save();

        res.json({ success: true, message: 'Password has been successfully updated.' });
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });
        
        if (!user) return res.status(401).json({ error: 'Invalid credentials' });
        
        // Validate password against hashed DB value
        const isMatch = await user.comparePassword(password);
        if (!isMatch) return res.status(401).json({ error: 'Invalid credentials' });
        
        // Generate Secure JSON Web Token
        const token = jwt.sign(
            { id: user._id, isAdmin: user.isAdmin },
            process.env.JWT_SECRET,
            { expiresIn: '1d' }
        );
        
        const userJSON = user.toJSON();
        userJSON.token = token; // Piggyback token to frontend state
        
        res.json(userJSON);
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

// ============================================
// SECURE ROUTES (Require JWT Authentication)
// ============================================

app.post('/api/projects', auth, async (req, res) => {
    try {
        const newProj = new Project({ ...req.body, status: 'Open' });
        await newProj.save();
        res.json(newProj);
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

app.post('/api/services', auth, async (req, res) => {
    try {
        const newServ = new Service(req.body);
        await newServ.save();
        res.json(newServ);
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

app.post('/api/proposals', auth, async (req, res) => {
    try {
        const newProp = new Proposal({ ...req.body, status: 'Submitted' });
        await newProp.save();
        res.json(newProp);
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

app.put('/api/users/:id', auth, async (req, res) => {
    try {
        // Enforce extreme security: Users can only edit themselves
        if (req.user.id !== req.params.id) {
            return res.status(403).json({ error: 'Unauthorized to edit this profile' });
        }
        
        const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedUser);
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

app.put('/api/hire', auth, async (req, res) => {
    try {
        const { proposalId, projectId } = req.body;
        
        // Verify user owns the project they are hiring someone for
        const project = await Project.findById(projectId);
        if(!project || project.postedBy !== req.user.id) {
            return res.status(403).json({ error: 'Unauthorized' });
        }

        await Proposal.findByIdAndUpdate(proposalId, { status: 'Hired' });
        await Project.findByIdAndUpdate(projectId, { status: 'Hired' });
        
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

// Admin Control
app.delete('/api/:type/:id', auth, async (req, res) => {
    try {
        if (!req.user.isAdmin) return res.status(403).json({ error: 'Admin access required' });
        
        const { type, id } = req.params;
        if (type === 'projects') await Project.findByIdAndDelete(id);
        else if (type === 'services') await Service.findByIdAndDelete(id);
        
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: 'Server Error' }); }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ MongoDB Backend Secure API Ready at http://localhost:${PORT}`));
